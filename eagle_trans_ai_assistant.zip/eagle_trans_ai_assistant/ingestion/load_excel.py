"""
load_excel.py

Reads shipment tracking Excel files and turns each row into a small
text document so the AI can retrieve it later.

Why row-by-row instead of one big document per file:
A shipment record is a self-contained fact ("Booking MSC458963 used
XYZ Logistics as loading yard"). Keeping rows separate means the
retrieval step can pull back exactly the one row that answers a
question, instead of a whole spreadsheet.
"""

import os
import pandas as pd
from llama_index.core import Document

from config import EXCEL_DIR


def _row_to_text(row: pd.Series, columns: list) -> str:
    """Turn one Excel row into a readable sentence-like string."""
    parts = []
    for col in columns:
        value = row[col]
        if pd.isna(value):
            continue
        parts.append(f"{col}: {value}")
    return " | ".join(parts)


def load_excel_documents(excel_dir: str = EXCEL_DIR) -> list:
    """
    Reads every .xlsx file in excel_dir (all sheets) and returns a list
    of llama_index Document objects, one per row.
    """
    documents = []

    if not os.path.isdir(excel_dir):
        print(f"[load_excel] Folder not found: {excel_dir}")
        return documents

    for filename in os.listdir(excel_dir):
        if not filename.lower().endswith((".xlsx", ".xls")):
            continue

        filepath = os.path.join(excel_dir, filename)
        try:
            sheets = pd.read_excel(filepath, sheet_name=None)  # dict of {sheet_name: DataFrame}
        except Exception as exc:
            print(f"[load_excel] Could not read {filename}: {exc}")
            continue

        for sheet_name, df in sheets.items():
            columns = list(df.columns)
            for row_index, row in df.iterrows():
                text = _row_to_text(row, columns)
                if not text:
                    continue

                doc = Document(
                    text=text,
                    metadata={
                        "source_type": "excel",
                        "file_name": filename,
                        "sheet_name": sheet_name,
                        "row_number": int(row_index) + 2,  # +2 accounts for header row and 0-index
                    },
                )
                documents.append(doc)

        print(f"[load_excel] Loaded {filename} - sheets: {list(sheets.keys())} - rows per sheet: { {k: len(v) for k,v in sheets.items()} }")

    print(f"[load_excel] Total rows converted to documents: {len(documents)}")
    return documents


if __name__ == "__main__":
    docs = load_excel_documents()
    if docs:
        print("\nSample document:")
        print(docs[0].text)
        print(docs[0].metadata)
