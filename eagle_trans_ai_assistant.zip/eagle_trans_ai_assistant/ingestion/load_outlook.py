"""
load_outlook.py

Reads emails directly from a running desktop Outlook application using
pywin32 COM automation.

IMPORTANT: This only works on Windows, with desktop Outlook installed
and signed in. It will not run on macOS, Linux, or with the new
Outlook web app. If you are demoing on a non-Windows machine, export
the relevant emails as .msg or .txt files into data/outlook_export
instead, and use load_outlook_export() further down in this file.
"""

import os
from llama_index.core import Document

from config import OUTLOOK_FOLDER_NAME, OUTLOOK_EXPORT_DIR


def load_outlook_documents(folder_name: str = OUTLOOK_FOLDER_NAME) -> list:
    """
    Connects to a running Outlook instance and reads emails from the
    given folder name (top-level folder under the default mailbox).
    """
    documents = []

    try:
        import win32com.client
    except ImportError:
        print("[load_outlook] pywin32 not installed or not on Windows. "
              "Skipping live Outlook read - use load_outlook_export() instead.")
        return documents

    try:
        outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
        inbox = outlook.GetDefaultFolder(6)  # 6 = olFolderInbox

        target_folder = inbox
        if folder_name.lower() != "inbox":
            # Support "Inbox/Subfolder" style paths
            parts = folder_name.split("/")[1:]
            for part in parts:
                target_folder = target_folder.Folders[part]

        messages = target_folder.Items
        messages.Sort("[ReceivedTime]", True)  # newest first

        for message in messages:
            try:
                subject = getattr(message, "Subject", "") or ""
                sender = getattr(message, "SenderName", "") or ""
                body = getattr(message, "Body", "") or ""
                received = str(getattr(message, "ReceivedTime", ""))

                text = f"Subject: {subject}\nFrom: {sender}\nDate: {received}\n\n{body}".strip()
                if not text:
                    continue

                doc = Document(
                    text=text,
                    metadata={
                        "source_type": "outlook",
                        "subject": subject,
                        "sender": sender,
                        "received": received,
                    },
                )
                documents.append(doc)
            except Exception as exc:
                print(f"[load_outlook] Skipped one message due to error: {exc}")
                continue

        print(f"[load_outlook] Loaded {len(documents)} emails from '{folder_name}'")

    except Exception as exc:
        print(f"[load_outlook] Could not connect to Outlook: {exc}")

    return documents


def load_outlook_export(export_dir: str = OUTLOOK_EXPORT_DIR) -> list:
    """
    Fallback loader for plain .txt exports of emails, one email per file.
    Useful when demoing on a machine without desktop Outlook, or when
    Outlook access is restricted by IT.

    Expected file content: same format the live loader produces above,
    i.e. Subject / From / Date on the first lines, blank line, then body.
    """
    documents = []

    if not os.path.isdir(export_dir):
        print(f"[load_outlook] Export folder not found: {export_dir}")
        return documents

    for filename in os.listdir(export_dir):
        if not filename.lower().endswith(".txt"):
            continue

        filepath = os.path.join(export_dir, filename)
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read().strip()

        if not text:
            continue

        documents.append(
            Document(
                text=text,
                metadata={"source_type": "outlook_export", "file_name": filename},
            )
        )

    print(f"[load_outlook] Loaded {len(documents)} exported email files")
    return documents


if __name__ == "__main__":
    docs = load_outlook_documents()
    if not docs:
        docs = load_outlook_export()
    if docs:
        print("\nSample document:")
        print(docs[0].text[:300])
        print(docs[0].metadata)
