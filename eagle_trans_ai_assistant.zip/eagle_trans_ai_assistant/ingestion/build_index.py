"""
build_index.py

This is the script that turns raw SOPs, Excel sheets, and emails into a
searchable knowledge base. Run this whenever source documents change.

What it does, step by step:
1. Loads documents from every source (Excel, PDF, DOCX, Outlook).
2. Splits long documents into smaller chunks (SOPs can be many pages).
3. Sends each chunk to the local Ollama embedding model, which turns
   text into a list of numbers (a "vector") capturing its meaning.
4. Stores those vectors in ChromaDB, a local vector database, so they
   can be searched later by similarity instead of exact keyword match.
5. Persists everything to disk so app.py can load it instantly without
   re-processing documents on every run.
"""

import sys
import os

# Allow running this script directly from the ingestion/ folder
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import chromadb
from llama_index.core import VectorStoreIndex, StorageContext, Settings
from llama_index.core.node_parser import SentenceSplitter
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore

from config import (
    CHROMA_DIR,
    CHROMA_COLLECTION_NAME,
    OLLAMA_EMBED_MODEL,
    OLLAMA_BASE_URL,
    CHUNK_SIZE,
    CHUNK_OVERLAP,
)
from ingestion.load_excel import load_excel_documents
from ingestion.load_pdf import load_pdf_documents
from ingestion.load_docx import load_docx_documents
from ingestion.load_outlook import load_outlook_documents, load_outlook_export


def gather_all_documents() -> list:
    """Collects documents from every source. Missing folders are skipped silently."""
    documents = []
    documents.extend(load_excel_documents())
    documents.extend(load_pdf_documents())
    documents.extend(load_docx_documents())

    from config import SKIP_OUTLOOK
    if not SKIP_OUTLOOK:
        outlook_docs = load_outlook_documents()
        if not outlook_docs:
            outlook_docs = load_outlook_export()
        documents.extend(outlook_docs)

    return documents


def build_index():
    print("Step 1/4: Gathering documents from all sources...")
    documents = gather_all_documents()

    if not documents:
        print("No documents found. Add files to the data/ subfolders first, then re-run.")
        return

    print(f"Total documents gathered: {len(documents)}")

    print("Step 2/4: Configuring the embedding model (Ollama - nomic-embed-text)...")
    Settings.embed_model = OllamaEmbedding(
        model_name=OLLAMA_EMBED_MODEL,
        base_url=OLLAMA_BASE_URL,
    )
    Settings.node_parser = SentenceSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
    )

    print("Step 3/4: Setting up ChromaDB storage...")
    os.makedirs(CHROMA_DIR, exist_ok=True)
    chroma_client = chromadb.PersistentClient(path=CHROMA_DIR)
    chroma_collection = chroma_client.get_or_create_collection(CHROMA_COLLECTION_NAME)
    vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
    storage_context = StorageContext.from_defaults(vector_store=vector_store)

    print("Step 4/4: Embedding documents and building the index (this can take a few minutes)...")
    index = VectorStoreIndex.from_documents(
        documents,
        storage_context=storage_context,
        show_progress=True,
    )

    print("\nDone. The knowledge base is ready.")
    print(f"Stored at: {CHROMA_DIR}")
    print("You can now run: streamlit run app.py")

    return index


if __name__ == "__main__":
    build_index()
