"""
load_pdf.py

Reads SOP PDF files and extracts text page by page using PyMuPDF (fitz).

Why page-by-page:
SOPs are procedural. Keeping the page as the unit means a citation like
"Source: SOP_VGM_Procedure.pdf, page 3" is meaningful to an employee
who wants to go check the original document.
"""

import os
import fitz  # PyMuPDF
from llama_index.core import Document

from config import SOPS_DIR


def load_pdf_documents(sops_dir: str = SOPS_DIR) -> list:
    documents = []

    if not os.path.isdir(sops_dir):
        print(f"[load_pdf] Folder not found: {sops_dir}")
        return documents

    for filename in os.listdir(sops_dir):
        if not filename.lower().endswith(".pdf"):
            continue

        filepath = os.path.join(sops_dir, filename)
        try:
            pdf = fitz.open(filepath)
        except Exception as exc:
            print(f"[load_pdf] Could not open {filename}: {exc}")
            continue

        for page_number, page in enumerate(pdf, start=1):
            text = page.get_text().strip()
            if not text:
                continue

            doc = Document(
                text=text,
                metadata={
                    "source_type": "pdf",
                    "file_name": filename,
                    "page_number": page_number,
                },
            )
            documents.append(doc)

        pdf.close()
        print(f"[load_pdf] Loaded {filename} ({page_number} pages)")

    print(f"[load_pdf] Total pages converted to documents: {len(documents)}")
    return documents


if __name__ == "__main__":
    docs = load_pdf_documents()
    if docs:
        print("\nSample document:")
        print(docs[0].text[:300])
        print(docs[0].metadata)
