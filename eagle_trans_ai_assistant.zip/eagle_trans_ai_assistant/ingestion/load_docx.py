"""
load_docx.py

Reads .docx SOP files and groups paragraphs under their nearest heading,
so each section becomes one document (e.g. all text under "VGM
Submission Procedure" stays together).
"""

import os
from docx import Document as DocxReader
from llama_index.core import Document

from config import SOPS_DIR


def _is_heading(paragraph) -> bool:
    style_name = paragraph.style.name if paragraph.style else ""
    return style_name.lower().startswith("heading")


def load_docx_documents(sops_dir: str = SOPS_DIR) -> list:
    documents = []

    if not os.path.isdir(sops_dir):
        print(f"[load_docx] Folder not found: {sops_dir}")
        return documents

    for filename in os.listdir(sops_dir):
        if not filename.lower().endswith(".docx"):
            continue

        filepath = os.path.join(sops_dir, filename)
        try:
            docx_file = DocxReader(filepath)
        except Exception as exc:
            print(f"[load_docx] Could not open {filename}: {exc}")
            continue

        current_heading = "General"
        current_section_text = []
        section_count = 0

        def flush_section():
            nonlocal section_count
            text = "\n".join(current_section_text).strip()
            if text:
                section_count += 1
                documents.append(
                    Document(
                        text=f"{current_heading}\n{text}",
                        metadata={
                            "source_type": "docx",
                            "file_name": filename,
                            "section_heading": current_heading,
                        },
                    )
                )

        for paragraph in docx_file.paragraphs:
            text = paragraph.text.strip()
            if not text:
                continue

            if _is_heading(paragraph):
                flush_section()
                current_heading = text
                current_section_text = []
            else:
                current_section_text.append(text)

        flush_section()  # capture the last section
        print(f"[load_docx] Loaded {filename} ({section_count} sections)")

    print(f"[load_docx] Total sections converted to documents: {len(documents)}")
    return documents


if __name__ == "__main__":
    docs = load_docx_documents()
    if docs:
        print("\nSample document:")
        print(docs[0].text[:300])
        print(docs[0].metadata)
