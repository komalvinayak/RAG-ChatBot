"""
app.py

The demo-facing chat interface. Run with:
    streamlit run app.py

It loads the vector index built by ingestion/build_index.py, sends the
employee's question through a local Llama 3.2 model along with the
most relevant retrieved chunks, and displays the answer with its
source documents.
"""

import os
import streamlit as st
import chromadb
from llama_index.core import VectorStoreIndex, Settings
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.vector_stores.chroma import ChromaVectorStore

from config import (
    CHROMA_DIR,
    CHROMA_COLLECTION_NAME,
    OLLAMA_LLM_MODEL,
    OLLAMA_EMBED_MODEL,
    OLLAMA_BASE_URL,
)


st.set_page_config(page_title="Eagle Trans AI Knowledge Assistant", layout="wide")


@st.cache_resource(show_spinner="Loading knowledge base...")
def load_query_engine():
    Settings.embed_model = OllamaEmbedding(
        model_name=OLLAMA_EMBED_MODEL,
        base_url=OLLAMA_BASE_URL,
    )
    Settings.llm = Ollama(
        model=OLLAMA_LLM_MODEL,
        base_url=OLLAMA_BASE_URL,
        request_timeout=120.0,
    )

    if not os.path.isdir(CHROMA_DIR):
        return None

    chroma_client = chromadb.PersistentClient(path=CHROMA_DIR)
    chroma_collection = chroma_client.get_or_create_collection(CHROMA_COLLECTION_NAME)
    vector_store = ChromaVectorStore(chroma_collection=chroma_collection)

    index = VectorStoreIndex.from_vector_store(vector_store)
    query_engine = index.as_query_engine(similarity_top_k=6, response_mode="compact")
    return query_engine


def format_source(node) -> str:
    """Builds a short, readable citation line from a retrieved node's metadata."""
    metadata = node.metadata or {}
    source_type = metadata.get("source_type", "unknown")

    if source_type == "excel":
        return f"{metadata.get('file_name')} - sheet '{metadata.get('sheet_name')}', row {metadata.get('row_number')}"
    if source_type == "pdf":
        return f"{metadata.get('file_name')} - page {metadata.get('page_number')}"
    if source_type == "docx":
        return f"{metadata.get('file_name')} - section '{metadata.get('section_heading')}'"
    if source_type in ("outlook", "outlook_export"):
        return f"Email - subject '{metadata.get('subject', metadata.get('file_name'))}'"
    return "Unknown source"


st.title("Eagle Trans - AI Knowledge Assistant (Demo)")
st.caption(
    "Ask a question about previous shipments, transporters, loading yards, or SOP procedures. "
    "This is a local prototype: no data leaves this machine."
)

query_engine = load_query_engine()

if query_engine is None:
    st.warning(
        "No knowledge base found yet. Add your SOPs, Excel sheets, and emails to the data/ "
        "folders, then run: python -m ingestion.build_index"
    )
    st.stop()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

for role, content, sources in st.session_state.chat_history:
    with st.chat_message(role):
        st.write(content)
        if sources:
            with st.expander("Sources"):
                for s in sources:
                    st.write(f"- {s}")

question = st.chat_input("Ask a question, e.g. Which transporter handled Booking MSC458963?")

if question:
    st.session_state.chat_history.append(("user", question, None))
    with st.chat_message("user"):
        st.write(question)

    with st.chat_message("assistant"):
        with st.spinner("Searching internal knowledge..."):
            response = query_engine.query(question)
            answer_text = str(response)
            seen = set()
            sources = []
            for node in response.source_nodes:
                s = format_source(node)
                if s not in seen:
                    seen.add(s)
                    sources.append(s)

        st.write(answer_text)
        if sources:
            with st.expander("Sources"):
                for s in sources:
                    st.write(f"- {s}")

    st.session_state.chat_history.append(("assistant", answer_text, sources))
