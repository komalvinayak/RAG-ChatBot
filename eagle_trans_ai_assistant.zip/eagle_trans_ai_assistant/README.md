# Eagle Trans AI Knowledge Assistant - Build Guide

A local, 100 percent free prototype of the AI Knowledge Assistant described in
the project proposal. It reads SOPs (PDF/DOCX), Excel shipment tracking
sheets, and Outlook emails, and lets an employee ask questions in plain
English and get an answer with the source document attached.

Everything runs on your own machine. No API keys, no cloud costs, no data
leaves the laptop - this is what makes it viable to demo for an MBA project
without licensing budget.

---

## 1. How it works (architecture)

This is called a RAG pipeline (Retrieval-Augmented Generation), though for
the business-facing proposal document you can just call it "the AI searches
company documents before answering."

```
 SOPs (PDF/DOCX)   Excel sheets   Outlook emails
        |               |               |
        v               v               v
   load_pdf.py    load_excel.py   load_outlook.py
   load_docx.py
        \               |               /
         \              |              /
          v             v             v
              build_index.py (chunking)
                        |
                        v
        Ollama embedding model (nomic-embed-text)
           turns each chunk into a vector
                        |
                        v
              ChromaDB (local vector database)
                 stores vectors on disk
                        |
      ---------------------------------------------
      |     app.py (Streamlit chat interface)      |
      |                                             |
      | Employee question                           |
      |     -> embed the question                   |
      |     -> find the closest matching chunks      |
      |     -> send question + chunks to Llama 3.2   |
      |     -> Llama 3.2 writes the answer            |
      |     -> answer + source shown to employee      |
      ---------------------------------------------
```

Two models are involved and they do different jobs:
- **nomic-embed-text**: converts text into numbers so similar meanings end up
  close together mathematically. This is what makes search "smart" instead of
  keyword-only.

- **llama3.2**: reads the retrieved chunks and writes a natural-language
  answer, the way a colleague would summarize what they found.

---

## 2. Prerequisites

| Tool | Purpose | Install from |
|---|---|---|
| Python 3.10+ | Runs all the scripts | python.org |
| Ollama | Runs the LLM and embedding model locally, free | ollama.com |
| Desktop Outlook (Windows only) | Needed only for the live email loader | Optional |

Everything else (LlamaIndex, ChromaDB, Streamlit, pandas, etc.) is installed
via pip and is free and open source.

---

## 3. Step-by-step setup

### Step 1: Install Ollama and pull the two models

Download and install Ollama for your OS, then in a terminal run:

```
ollama pull llama3.2
ollama pull nomic-embed-text
```

Leave Ollama running in the background (it starts a local server at
`http://localhost:11434` automatically).

### Step 2: Create a virtual environment and install dependencies

```
cd eagle_trans_ai_assistant
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate

pip install -r requirements.txt
```

Note: `pywin32` in requirements.txt only installs on Windows. 

If you are on
Mac or Linux, remove that line before running pip install, and use the
`load_outlook_export()` fallback described in Step 3 instead of the live
Outlook reader.

### Step 3: Add your source documents

Place files into the matching folder:

```
data/sops/            -> SOP PDFs and DOCX files (VGM procedure, SI submission, etc.)
data/excel/           -> Shipment tracking Excel files (.xlsx)
data/outlook_export/  -> Only needed if not using live Outlook: plain .txt exports,
                          one email per file, formatted as:
                            Subject: ...
                            From: ...
                            Date: ...
                            (blank line)
                            (email body)
```

If you are on Windows with desktop Outlook open and signed in, you do not
need to export anything manually - `load_outlook.py` reads directly from your
Inbox (or a subfolder, configurable in `config.py`).

### Step 4: Build the knowledge base

From the project root, with the virtual environment active:

```
python -m ingestion.build_index
```

This reads every file, splits long SOPs into chunks, embeds everything with
nomic-embed-text, and stores it in `storage/chroma_db/`. Re-run this any time
source documents change.

### Step 5: Launch the demo

```
streamlit run app.py
```

This opens a chat interface in your browser. Try the example questions from
the proposal, such as:
- Which loading yard was used for Customer ABC's previous shipment?
- Which transporter handled Booking MSC458963?
- What are the VGM requirements?

Each answer shows an expandable "Sources" section citing the exact file, page,
sheet, or email it came from - this is what makes the tool trustworthy rather
than a black box.

---

## 4. Project structure

```
eagle_trans_ai_assistant/
  config.py                  All paths and model settings in one place
  requirements.txt
  app.py                     Streamlit chat interface
  data/
    sops/                    Put PDF/DOCX SOPs here
    excel/                   Put shipment tracking .xlsx files here
    outlook_export/          Optional .txt email exports
  ingestion/
    load_excel.py            Excel -> Document objects, one per row
    load_pdf.py               PDF -> Document objects, one per page
    load_docx.py              DOCX -> Document objects, one per section
    load_outlook.py           Outlook -> Document objects, one per email
    build_index.py            Combines all sources, embeds, stores in ChromaDB
  storage/
    chroma_db/                 Persisted vector database (created on first run)
```

---

## 5. Keeping the knowledge base up to date (automation with n8n)

The proposal mentions "automatic updates when new documents are added." Since
n8n Community Edition is free and self-hosted, a simple version of this for a
demo looks like:

1. Install n8n locally (`npx n8n`, no license needed for Community Edition).
2. Create a workflow with a **Schedule Trigger** node (e.g. every night at
   2 AM) or a **Local File Trigger** node watching the `data/` folder for
   changes.
3. Add an **Execute Command** node that runs:
   ```
   python -m ingestion.build_index
   ```
4. Optionally add a **Send Email** node afterward to notify the team that the
   knowledge base was refreshed.

This keeps the "automatic updates" future-scope item real and demoable
without writing custom scheduling code.

---

## 6. What to say in the demo (mapping back to the proposal)

- "Employee needs information" -> the Streamlit chat input.
- "AI searches internal knowledge" -> the embedding + ChromaDB retrieval step.
- "Generates an accurate response with the source" -> the answer plus the
  Sources expander.
- "Reduced manual effort, faster decision-making" -> point out you no longer
  need to filter Excel manually or search Outlook - the chat did it in
  seconds.

## 7. Honest limitations to mention (this is what makes an MBA project credible)

- This is a local prototype, not a production system - it has no
  authentication, no encryption at rest beyond your machine's own security,
  and is not integrated with the company's real email/ERP systems.
- Answer quality depends on how much and how clean the source data is; a
  small demo dataset will give noticeably better answers on questions closely
  matching the data than a small, sparse one.
- The live Outlook reader is Windows-only and requires desktop Outlook
  signed in locally; a production rollout would use the Microsoft Graph API
  instead, which needs IT approval and was intentionally left out of this
  free prototype.
- Llama 3.2 running locally is smaller than commercial cloud models, so for a
  production deployment you may want to benchmark it against a hosted option
  before committing budget.

## 8. Future scope (from the proposal, and how each maps to this stack)

| Future item | How it would extend this prototype |
|---|---|
| Automatic email drafting | Add a second Ollama prompt that drafts a reply using the same retrieved context |
| Microsoft Teams integration | Wrap the query engine in a small API and connect it to a Teams bot |
| Voice-enabled assistant | Add a speech-to-text step (e.g. Whisper, also free) before the chat input |
| ERP/shipment system integration | Add a new loader script alongside load_excel.py that reads from the ERP's export or API |
| Dashboard of frequent queries | Log each question asked in app.py to a simple CSV or SQLite file, then chart it |
