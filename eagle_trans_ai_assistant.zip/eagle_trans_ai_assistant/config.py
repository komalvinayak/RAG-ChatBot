"""
config.py

Central place for all folder paths and model settings.
Change values here instead of editing every script.
"""

import os

# Root folder of the project
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Where raw source documents live
DATA_DIR = os.path.join(BASE_DIR, "data")
SOPS_DIR = os.path.join(DATA_DIR, "sops")              # PDF and DOCX SOPs
EXCEL_DIR = os.path.join(DATA_DIR, "excel")             # Shipment tracking sheets
OUTLOOK_EXPORT_DIR = os.path.join(DATA_DIR, "outlook_export")  # .msg exports, fallback if Outlook COM is unavailable

# Where the vector index is persisted so it does not need to be rebuilt every run
STORAGE_DIR = os.path.join(BASE_DIR, "storage")
CHROMA_DIR = os.path.join(STORAGE_DIR, "chroma_db")
CHROMA_COLLECTION_NAME = "eagle_trans_knowledge"

# Ollama models (both must be pulled locally before running anything, see README)
OLLAMA_LLM_MODEL = "llama3.2"
OLLAMA_EMBED_MODEL = "nomic-embed-text"
OLLAMA_BASE_URL = "http://localhost:11434"

# Outlook folder to read emails from, e.g. "Inbox" or "Inbox/EagleTrans"
OUTLOOK_FOLDER_NAME = "Inbox"
SKIP_OUTLOOK = True

# Chunking settings for long documents (SOPs)
CHUNK_SIZE = 512
CHUNK_OVERLAP = 50
